export default () => (<div className="lds-dual-ring"/>)
